import logging
from urllib.parse import urlencode
from xml.etree.cElementTree import ElementTree as ET


class XMLEtAnalyzer(ET):
    """爬虫项目 任务配置 XML文件 解析器"""

    def __init__(self, file):
        """
        实例化
        :param file: XML文件路径
        """
        super(XMLEtAnalyzer, self).__init__(file=file)

    @property
    def get_urls(self):
        """
        获取urls节点
        :return: list(node)
        """
        return list(self.iter('urls'))

    @property
    def get_urls_text(self):
        """
        获取所有url拼装后的文本
        :return: list('http://www.example.com/?a=1&b=2',...)
        (url参数中文参数已转码)
        [
            'http://amazon.com.au/?category=beautify&page=2&page2=None',
            'http://amazon.com.au/?category=beautify%E4%B8%AD%E6%96%87&keyword=beautify&page=2',
            'http://amazon.com.au/?category=beautify&page=2'
        ]
        """
        text_list = []
        try:
            urls = list(self.iter('url'))
            for i in urls:
                params_list = list(i.iterfind('params/param'))
                params = {p.get('name'): p.text for p in params_list}
                text_list.append('%s://%s/%s%s' % (list(i.iter('mode'))[0].text,
                                                   list(i.iter('host'))[0].text,
                                                   list(i.iter('path'))[0].text,
                                                   urlencode(params)))

            return text_list
        except Exception as e:
            logging.error('XML解析错误')
            logging.info(e)
        finally:
            return text_list

    @property
    def get_requests(self):
        """
        获取请求配置节点
        :return:
        """
        return list(self.iter('requests'))

    @property
    def get_requests_dict(self):
        """
        获取请求配置节点的dict
        :return: dict('delay':1,...)
        {
            'delay': '1',
            'max_thread': '16',
            'cookies': '123',
            'user_agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/537.36 (KHTML, like Gecko)Chrome/68.0.3440.106 Safari/537.36',
            'user_accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
        }
        """
        try:
            items = list(self.iter('requests'))[0].getchildren()
            return {i.tag: i.text for i in items}
        except Exception as e:
            logging.error('XML解析错误')
            logging.info(e)
            return {}

    @property
    def get_task(self):
        return list(self.iter('task'))

    @property
    def get_task_dict(self):
        try:
            items = list(self.iter('task'))[0].getchildren()
            return {i.tag: i.text for i in items}
        except Exception as e:
            logging.error('XML解析错误')
            logging.info(e)
            return {}

    @property
    def get_proxy(self):
        """
        获取代理节点
        :return:
        """
        return list(self.iterfind('proxys/proxy'))

    @property
    def get_proxy_list(self):
        """
        获取代理配置列表
        :return:
        [
            {'type': '1', 'proxy': '8.8.8.8'},
            {'type': '1', 'proxy': '8.8.8.7'},
            {'type': '1', 'proxy': '8.8.8.9'},
            {'type': '1', 'proxy': '8.8.8.6'}
        ]
        """
        proxy_list = self.get_proxy
        return [{**i.attrib, 'proxy': i.text} for i in proxy_list]

    def get_tree(self, node=None, node_list=None):
        """
        遍历XML节点树
        :param node: 起始节点
        :param node_list: 当前节点列表
        :return: 遍历节点树 list(dict(),dict(),dict(child_node:list()))
        """

        if node_list is None:
            node_list = []
        if node is None:
            node = self._root

        children = node.getchildren()
        if len(children) > 0:
            for child in children:
                if child.getchildren():
                    child_list = yield self.get_tree(node=child)
                else:
                    child_list = []

                child_node = dict(name=child.tag, item=child, children=child_list)
                node_list.append(child_node)

        return node_list