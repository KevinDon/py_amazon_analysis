import os
import zipfile


def zip_files(file_list, zip_name, out_path='.\\'):
    zip_handler = zipfile.ZipFile(os.path.abspath(os.path.join(out_path, zip_name)), 'w', zipfile.ZIP_DEFLATED)
    for file in file_list:
        print('Compressing zip ', file)
        zip_handler.write(file)
    zip_handler.close()
    print('Compressing Finished')


def unzip_file(file_path, out_path='.\\'):
    zip_handler = zipfile.ZipFile(file_path, 'r')
    for file in zip_handler.namelist():
        zip_handler.extract(file, out_path)


if __name__ == '__main__':
    files = ['XMLAnalyzer.py', 'ZIPHandler.py',
             r'E:\phpStudy\PHPTutorial\WWW\python\amazonAnalysis_branch1\sever\data\na_business_report_20190703.sql']
    zip_file = '.\\test.zip'
    zip_files(files, zip_file)

if __name__ == '__main__':
    file = '.\\test.zip'
    unzip_file(file)
